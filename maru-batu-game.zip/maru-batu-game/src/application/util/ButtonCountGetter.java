package application.util;

public interface ButtonCountGetter {
	
	public int getButtonCount();

}
